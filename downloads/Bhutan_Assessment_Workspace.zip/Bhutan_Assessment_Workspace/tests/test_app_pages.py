"""Every page must load with no exception (no upload needed)."""
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent

def _call(mod, fn):
    import importlib
    getattr(importlib.import_module(mod), fn)()

PAGES = [("pages.true_false","render"),("pages.fill_blank","render"),("pages.matching","render"),
         ("pages.written_response","render"),("pages.score_statistics","render"),("pages.home","render")] + \
        [("pages.guides",f) for f in ("about","how_it_works","item_guide","decision_rules",
         "statistical_tests_guide","methodology","data_format","sample_data","contact","feedback")]

@pytest.mark.parametrize("mod,fn", PAGES)
def test_page_loads(mod, fn):
    at = AppTest.from_function(_call, args=(mod, fn), default_timeout=60).run()
    assert not at.exception, at.exception

def test_entry_point_and_navigation():
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=90).run()
    assert not at.exception, at.exception
    at.button(key="open_workspace_home").click().run()
    assert [b.key for b in at.button if b.key.startswith("choose_")] == [
        "choose_mcq", "choose_true_false", "choose_fill_blank", "choose_matching",
        "choose_written", "choose_statistics",
    ]
    assert any(h.value == "Choose a test item" for h in at.header)
    assert "Item Analyzer" in " ".join(m.value for m in at.markdown)

def test_legacy_mcq_page_loads():
    at = AppTest.from_file(str(ROOT / "pages" / "mcq.py"), default_timeout=90).run()
    assert not at.exception, at.exception

def test_language_switch_persists_across_navigation():
    from utils.dzongkha import DZ

    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    at.button(key="open_workspace_home").click().run()
    from components.navigation import PAGES as ROUTES
    at._page_hash = ROUTES["home"]._script_hash
    at.button(key="language_dz").click().run()
    assert at.header[0].value == DZ["sec_choose"]
    at.button(key="choose_statistics").click().run()
    assert not at.exception
    assert at.header[0].value == DZ["sec_dist"]
    at._page_hash = ROUTES["statistics"]._script_hash
    at.button(key="language_en").click().run()
    assert "Item Analyzer" in " ".join(m.value for m in at.markdown)
